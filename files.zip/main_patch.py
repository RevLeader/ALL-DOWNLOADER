"""
main_patch.py
-------------
This file shows the EXACT changes to make in your existing main.py.
It is NOT a replacement — apply only the marked diffs below.

Search for each "FIND THIS" block in your main.py and replace/add
the corresponding "REPLACE WITH / ADD AFTER" block.
"""


# ════════════════════════════════════════════════════════════════════════════
# CHANGE 1 — Import the refresher (add near the top, after other imports)
# ════════════════════════════════════════════════════════════════════════════

# FIND THIS (already in main.py):
# from app.auth import (

# ADD THESE TWO LINES DIRECTLY ABOVE IT:
from app.cookie_refresher import CookieRefresher   # ← ADD
# (keep the existing from app.auth import block below, unchanged)


# ════════════════════════════════════════════════════════════════════════════
# CHANGE 2 — Start the refresher once DOWNLOADS_DIR is set up
# ════════════════════════════════════════════════════════════════════════════

# FIND THIS (already in main.py, lines ~49-51):
#
#   APP_DIR = Path(__file__).parent
#   DOWNLOADS_DIR = APP_DIR / "downloads"
#   DOWNLOADS_DIR.mkdir(exist_ok=True)

# ADD THESE LINES RIGHT AFTER (after DOWNLOADS_DIR.mkdir):
cookie_refresher = CookieRefresher(cookies_dir=DOWNLOADS_DIR)   # ← ADD
cookie_refresher.start()                                          # ← ADD


# ════════════════════════════════════════════════════════════════════════════
# CHANGE 3 — Trigger force_refresh() on bot-detection errors in run_job()
# ════════════════════════════════════════════════════════════════════════════

# FIND THIS block (already in main.py, inside run_job()):
#
#     except yt_dlp.utils.DownloadError as e:
#         if job.cancel_requested:
#             job.status = JobStatus.CANCELLED
#             job.add_log("Cancelled.")
#         else:
#             job.status = JobStatus.ERROR
#             job.error = str(e)
#             job.add_log(f"Error: {e}")
#         _persist(job)

# REPLACE WITH:
"""
    except yt_dlp.utils.DownloadError as e:
        if job.cancel_requested:
            job.status = JobStatus.CANCELLED
            job.add_log("Cancelled.")
        else:
            job.status = JobStatus.ERROR
            job.error = str(e)
            job.add_log(f"Error: {e}")
            # ↓ ADD: trigger background cookie refresh on bot-detection errors
            _BOT_ERROR_PHRASES = [
                "sign in to confirm",
                "confirm you're not a bot",
                "not a bot",
                "http error 429",
                "too many requests",
            ]
            if any(p in str(e).lower() for p in _BOT_ERROR_PHRASES):
                job.add_log("⚠ Bot check detected — refreshing cookies in background. Retry this job in ~30s.")
                cookie_refresher.force_refresh()
            # ↑ END ADD
        _persist(job)
"""


# ════════════════════════════════════════════════════════════════════════════
# CHANGE 4 — Add a /api/cookies/refresh_status endpoint (optional but useful)
#            Place it alongside your existing /api/cookies/status endpoint
# ════════════════════════════════════════════════════════════════════════════

# ADD THIS ENDPOINT after the existing @app.get("/api/cookies/status") route:
"""
@app.get("/api/cookies/refresher", dependencies=[Depends(require_login)])
def cookie_refresher_status():
    \"\"\"
    Returns the status of the automatic cookie refresher background service.
    Useful for debugging whether auto-refresh is working.
    \"\"\"
    return cookie_refresher.status()


@app.post("/api/cookies/force_refresh", dependencies=[Depends(require_login)])
def trigger_cookie_refresh():
    \"\"\"
    Manually trigger an immediate background cookie refresh.
    The refresh runs asynchronously; poll /api/cookies/refresher to see when it completes.
    \"\"\"
    cookie_refresher.force_refresh()
    return {"ok": True, "message": "Cookie refresh triggered in background. Check /api/cookies/refresher for status."}
"""
